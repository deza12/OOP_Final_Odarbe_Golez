﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library_Management_System
{
    class User
    {
        public String FirstName, LastName, MiddleName, UserName, Password;

        public User(String firstname, String lastname, String middlename, String username, String password)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.MiddleName = middlename;
            this.UserName = username;
            this.Password = password;

        }
        public String toString()
        {
            return "User{" +
                    "FirstName='" + FirstName + '\'' +
                    ", LastName='" + LastName + '\'' +
                    ", MiddleName='" + MiddleName + '\'' +
                    ", UserName='" + UserName + '\'' +
                    ", Password='" + Password + '\'' +
                    '}';
        }
        public User(String id, String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

    }
}

