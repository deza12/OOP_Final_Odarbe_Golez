﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library_Management_System
{
    class Date
    {
        public void dateb()
        {
            string month;
            int date, year = 2018;
            Console.WriteLine("************************************************************");
            Console.WriteLine("***********  LIBRARY RECEIPT FOR BORROWED BOOK'S ***********");
            Console.WriteLine("************************************************************");
            Console.WriteLine("***** NOTE:           **************************************");
            Console.WriteLine("  NO Borrowing of Books at END OF THE Month Due to Checking ");
            Console.WriteLine("           of Stock of BookList. THANK YOU !!!!             ");
            Console.WriteLine("********* DETAILS OF BORROWED :  ***************************");
            Console.Write("      Month:");
            month = Console.ReadLine();
            Console.Write("      Date:");
            date = int.Parse(Console.ReadLine());
            Console.Write("     Year:" + year);
            Console.WriteLine();
            Console.WriteLine("********* DATE SHOULD BE RETURNED : ************************");
            Console.WriteLine("       Month:" + month);
            Console.WriteLine("       Date: " + (date + 2));
            Console.WriteLine("       Year:" + year);
            Console.WriteLine("************************************************************");

            string option;
            Console.Write("Do you Want to Go Back Home? (y/Y)");
            option = Console.ReadLine();

            if (option == "y" || option == "Y")
            {
                Console.Clear();
                BookList m = new BookList();
                m.List();
            }
            else
            {
                Console.Clear();
                LogIn l = new LogIn();
                l.Login();
            }
        }
    }
}
