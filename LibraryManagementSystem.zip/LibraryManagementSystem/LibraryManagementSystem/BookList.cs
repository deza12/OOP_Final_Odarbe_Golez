﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library_Management_System
{
    class BookList
    {
        public void List()
        {
            String choice;
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************        NAME OF BOOKS       ********************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**                      A. English                            **");
            Console.WriteLine("**                      B. MATH                               **");
            Console.WriteLine("**                      C. FILIPINO                           **");
            Console.WriteLine("**                      D. SCIENCE                            **");
            Console.WriteLine("**                      E. FICTION                            **");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine();
            Console.Write("Input subject:");
            choice = Console.ReadLine();


            switch (choice)
            {
                case "a":
                case "A":
                    Console.WriteLine("ENGLISH !!!!");
                    English();
                    break;
                case "b":
                case "B":
                    Console.WriteLine("MATH !!!!");
                    Math();
                    break;
                case "c":
                case "C":
                    Console.WriteLine("SCIENCE !!!!");
                    Science();
                    break;
                case "d":
                case "D":
                    Console.WriteLine("FILIPINO !!!!");
                    Filipino();
                    break;
                case "e":
                case "E":
                    Console.WriteLine("FICTION !!!!");
                    Fiction();
                    break;

                default:
                    Console.WriteLine("********************** INVALID CHOICE *****************************");
                    List();
                    break;
            }

        }


        public void English()
        {
            int choice;
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**                      A. English                            **");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**********  1.Technical Writing  *******************************");
            Console.WriteLine("**********  2.Oral Speech        *******************************");
            Console.WriteLine("**********  3.Writing Discipline *******************************");
            Console.WriteLine("**********  4.English Plus       *******************************");
            Console.WriteLine("**********  5.Study and Thinking *******************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.Write("Input choice:");
            choice = int.Parse(Console.ReadLine());



            try
            {
                switch (choice)
                {

                    case 1:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      1. Technical Writing            ********");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Technical Writing Book: 30");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed1 = int.Parse(Console.ReadLine());
                        int totalTW = 30 - borrowed1;
                        Console.WriteLine("Remaining Technical Writing Book:" + totalTW);
                        Date c = new Date();
                        c.dateb();
                        break;
                    case 2:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      2. Oral Speech                  ********");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Oral Speeech Book: 20");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed2 = int.Parse(Console.ReadLine());
                        int totalOS = 20 - borrowed2;
                        Console.WriteLine("Remaining Oral Speech Book:" + totalOS);
                        Date d = new Date();
                        d.dateb();
                        break;

                    case 3:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      3.Writing Discipline             *******");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Writing Discipline Book: 50");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed3 = int.Parse(Console.ReadLine());
                        int totalWD = 50 - borrowed3;
                        Console.WriteLine("Remaining Writing Discipline Book:" + totalWD);
                        Date r = new Date();
                        r.dateb();
                        break;

                    case 4:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      4. English Plus                   **");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of English Plus Book: 100");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed4 = int.Parse(Console.ReadLine());
                        int totalEP = 100 - borrowed4;
                        Console.WriteLine("Remaining English Plus Book:" + totalEP);
                        Date j = new Date();
                        j.dateb();
                        break;

                    case 5:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                    5. Study and Thinking                  **");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Study and Thinking  Book: 80");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed5 = int.Parse(Console.ReadLine());
                        int totalST = 80 - borrowed5;
                        Console.WriteLine("Remaining Study and Thinking  Book:" + totalST);
                        Date u = new Date();
                        u.dateb();
                        break;
                }
            }
            catch
            {
                Console.WriteLine("********************** INVALID CHOICE *****************************");
                List();
            }



        }
        public void Math()
        {
            int choice;
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**                      B. Math                               **");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("******* 1.College Algebra  *************************************");
            Console.WriteLine("******* 2.Mathematics of Invesment  ****************************");
            Console.WriteLine("******* 3.Discreate Math   *************************************");
            Console.WriteLine("******* 4.Basic Mathematics ************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.Write("Input choice:");
            choice = int.Parse(Console.ReadLine());


            try
            {
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      1. College Algebra                   **");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of College Algebra Book: 40");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed1 = int.Parse(Console.ReadLine());
                        int totalCA = 40 - borrowed1;
                        Console.WriteLine("Remaining College Algebra Book:" + totalCA);
                        Date d = new Date();
                        d.dateb();
                        break;

                    case 2:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      2.Mathematics of Invesment            **");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Mathematics of Invesment Book: 30");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed2 = int.Parse(Console.ReadLine());
                        int totalMI = 30 - borrowed2;
                        Console.WriteLine("Remaining Mathematics of Invesment:" + totalMI);
                        Date m = new Date();
                        m.dateb();
                        break;


                    case 3:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      3. Discreate Math                     **");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Discreate Math Book: 100");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed3 = int.Parse(Console.ReadLine());
                        int totalDM = 100 - borrowed3;
                        Console.WriteLine("Remaining Discreate Math Book:" + totalDM);
                        Date z = new Date();
                        z.dateb();
                        break;

                    case 4:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                    4. Basic Mathematics                    **");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Total of Basic Mathematics Book: 200");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed4 = int.Parse(Console.ReadLine());
                        int totalBM = 200 - borrowed4;
                        Console.WriteLine("Remaining Basic Mathematics Book:" + totalBM);
                        Date b = new Date();
                        b.dateb();
                        break;
                }
            }
            catch
            {
                Console.WriteLine("********************** INVALID CHOICE *****************************");
                List();
            }



        }
        public void Filipino()
        {

            int choice;
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**                      C. FILIPINO                           **");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**********  1.Pagbasa at Pagsulat  *****************************");
            Console.WriteLine("**********  2.Wika at Komunikasyon *****************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.Write("Input choice:");
            choice = int.Parse(Console.ReadLine());
            Console.ReadLine();


            switch (choice)
            {
                case 1:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                      1.Pagbasa at Pagsulat                 **");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Pagbasa at Pagsulat Book: 50");
                    Console.Write(" No. of Books Borrowed:");
                    int borrowed1 = int.Parse(Console.ReadLine());
                    int totalPP = 50 - borrowed1;
                    Console.WriteLine("Remaining Pagbasa at Pagsulat:" + totalPP);
                    Date i = new Date();
                    i.dateb();
                    break;

                case 2:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                      2.Wika at Komunikasyon                **");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Wika at Komunikasyon Book: 70");
                    Console.Write(" No. of Books Borrowed:");
                    int borrowed2 = int.Parse(Console.ReadLine());
                    int totalWK = 70 - borrowed2;
                    Console.WriteLine("Remaining Wika at Komunikasyon:" + totalWK);
                    Date y = new Date();
                    y.dateb();
                    break;
            }



        }
        public void Science()
        {
            int choice;
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**                      D. SCIENCE                            **");
            Console.WriteLine("****************************************************************");
            Console.WriteLine(" How many books you will borrow?");
            Console.WriteLine(" Total of Technical Writing Book: 30");
            Console.Write(" No. of Books Borrowed:");
            int borrowed1 = int.Parse(Console.ReadLine());
            int totalTW = 30 - borrowed1;
            Console.WriteLine("Remaining Technical Writing Book:" + totalTW);
            Date c = new Date();
            Console.WriteLine("*********  1.Natural Science  **********************************");
            Console.WriteLine("*********  1.Natural Science  **********************************");
            Console.WriteLine("*********  2.Social Science   **********************************");
            Console.WriteLine("*********  3.Biological Science  *******************************");
            Console.WriteLine("*********  4.Physical Science  *********************************");
            Console.WriteLine("*********  5.Biochemistry   ************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.Write("Input choice:");
            choice = int.Parse(Console.ReadLine());
            Console.ReadLine();


            switch (choice)
            {
                case 1:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                      1. Natural Science                  ****");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Natural Science Book: 10");
                    Console.Write("No. of Books Borrowed:");
                    int borrowed = int.Parse(Console.ReadLine());
                    int totalNS = 10 - borrowed1;
                    Console.WriteLine("Remaining Natural Science Book:" + totalNS);
                    Date d = new Date();
                    d.dateb();
                    break;

                case 2:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                      2. Social Science                   ****");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Social Science Book: 60");
                    Console.Write(" No. of Books Borrowed:");
                    int borrowed2 = int.Parse(Console.ReadLine());
                    int totalSS = 60 - borrowed2;
                    Console.WriteLine("Remaining Social Science Book:" + totalSS);
                    Date t = new Date();
                    t.dateb();
                    break;

                case 3:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                      3.Biological Science                 ***");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Biological Science Book: 50");
                    Console.Write(" No. of Books Borrowed:");
                    int borrowed3 = int.Parse(Console.ReadLine());
                    int totalBS = 50 - borrowed3;
                    Console.WriteLine("Remaining Biological Science Book:" + totalBS);
                    Date n = new Date();
                    n.dateb();
                    break;

                case 4:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                      4.Physical Science                  ****");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Physical Science Book: 300");
                    Console.Write(" No. of Books Borrowed:");
                    int borrowed4 = int.Parse(Console.ReadLine());
                    int totalPS = 300 - borrowed4;
                    Console.WriteLine("Remaining Physical Science Book:" + totalPS);
                    Date h = new Date();
                    h.dateb();
                    break;

                case 5:
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("**                    5.Biochemistry                 ***********");
                    Console.WriteLine("****************************************************************");
                    Console.Write("How many books you will borrow?");
                    Console.WriteLine(" Total of Biochemistry  Book: 90");
                    Console.Write(" No. of Books Borrowed:");
                    int borrowed5 = int.Parse(Console.ReadLine());
                    int totalB = 90 - borrowed5;
                    Console.WriteLine("Remaining Biochemistry  Book:" + totalB);
                    Date x = new Date();
                    x.dateb();
                    break;

            }

        }
        public void Fiction()
        {
            int choice;
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**                      E. FICTION                       *******");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("**********  1.Science fiction  *********************************");
            Console.WriteLine("**********  2.Drama       **************************************");
            Console.WriteLine("**********  3.Action And Adventure  ****************************");
            Console.WriteLine("**********  4.Romance   ****************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.Write("Input choice:");
            choice = int.Parse(Console.ReadLine());


            try
            {
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      1. Science fiction              ********");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Science fiction Book: 40");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed1 = int.Parse(Console.ReadLine());
                        int totalSF = 40 - borrowed1;
                        Console.WriteLine("Remaining Science fiction Book:" + totalSF);
                        Date d = new Date();
                        d.dateb();
                        break;

                    case 2:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      2. Drama                         *******");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Drama Book: 50 Pcs.");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed2 = int.Parse(Console.ReadLine());
                        int totalD = 50 - borrowed2;
                        Console.WriteLine("Remaining Drama Book:" + totalD);
                        Date m = new Date();
                        m.dateb();
                        break;

                    case 3:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      3.Action And Adventure             *****");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Action And Adventure Book: 100");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed3 = int.Parse(Console.ReadLine());
                        int totalAA = 100 - borrowed3;
                        Console.WriteLine("Remaining Action And Adventure Book:" + totalAA);
                        Date k = new Date();
                        k.dateb();
                        break;

                    case 4:
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("**                      4.Horror                           *****");
                        Console.WriteLine("****************************************************************");
                        Console.Write("How many books you will borrow?");
                        Console.WriteLine(" Horror Book: 400");
                        Console.Write(" No. of Books Borrowed:");
                        int borrowed4 = int.Parse(Console.ReadLine());
                        int totalH = 400 - borrowed4;
                        Console.WriteLine("Remaining Horror Book:" + totalH);
                        Date v = new Date();
                        v.dateb();
                        break;



                }
            }
            catch
            {
            }
        }
    }
}