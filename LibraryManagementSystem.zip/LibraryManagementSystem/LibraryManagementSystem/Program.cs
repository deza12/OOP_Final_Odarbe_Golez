﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library_Management_System
{
    class Program
    {
        static void Main(string[] args)
        {
            LogIn p = new LogIn();

            p.Login();
            Console.Clear();

            BookList m = new BookList();
            m.List();

            Console.Read();
        }
        public void Home()
        {

        }
    }

}
      