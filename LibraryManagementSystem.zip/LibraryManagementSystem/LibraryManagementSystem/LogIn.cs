﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library_Management_System
{
    class LogIn
    {
        public void Login()
        {
            string user;
            string password = "";
            string name = "dezacath";
            string pass = "project123";
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("*********    Welcome Library Management System        **********");
            Console.WriteLine("****************************************************************");
            Console.WriteLine("*************            LOGIN        **************************");
            Console.Write("              Please Input Username: ");
            user = Console.ReadLine();
            Console.Write("              Please Input Password:");
            password = Console.ReadLine();
            Console.WriteLine("****************************************************************");
            Console.WriteLine("****************************************************************");


            if (user == name & password == pass)
            {
                Console.Clear();
                BookList m = new BookList();
                m.List();

            }
            else
            {
                Console.WriteLine(" E R R O R ");
                Login();
            }

            Console.Clear();
        }


    }
}

