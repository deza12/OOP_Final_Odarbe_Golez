﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library_Management_System
{
    class DataSet
    {


        // static Story[] booklist;
        public static List<User> UserList = new List<User>();
        public static List<LogIn> LogInHome = new List<LogIn>();
        public static List<Date> DateList = new List<Date>();


        // static List<String> names;
    }
}
